package com.example.jss.recognition;

import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;
import android.app.AlertDialog;
import android.content.Context;

import java.util.*;
import java.util.Map.Entry;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btncamera = (Button)findViewById(R.id.btnCamera);
        imageView = (ImageView)findViewById(R.id.ImageView);

        btncamera.setOnClickListener(new View.OnClickListener() {
            public void onClick (View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 0);
            }

        });
    }
    /*
    public static <T> T mostCommon(List<T> list) {
        Map<T, Integer> map = new HashMap<>();

        for (T t : list) {
            Integer val = map.get(t);
            map.put(t, val == null ? 1 : val + 1);
        }

        Entry<T, Integer> max = null;

        for (Entry<T, Integer> e : map.entrySet()) {
            if (max == null || e.getValue() > max.getValue())
                max = e;
        }

        return max.getKey();
    }
*/
    public static <T> T mostCommon(List<T> list) {
        Map<T, Integer> map = new HashMap<>();

        for (T t : list) {
            Integer val = map.get(t);
            map.put(t, val == null ? 1 : val + 1);
        }

        Entry<T, Integer> max = null;

        for (Entry<T, Integer> e : map.entrySet()) {
            if (max == null || e.getValue() > max.getValue())
                max = e;
        }

        return max.getKey();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultcode, Intent data){

        final Context context = this;


        super.onActivityResult(requestCode, resultcode, data);

        Bitmap bitmap = (Bitmap)data.getExtras().get("data");

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

/*
        for(int h = 0; h<height; h++) {
            for (int w = 0; w < width; w++) {
                bitmap.setPixel(w, h, Color.rgb(255, 0, 0));

            }
        }
*/
        imageView.setImageBitmap(bitmap);

        // value declaration
        int R, G, B;

        int variance = 50;
        //1. Get size of width and height in pixels

        // get middle region of the image
        int width3 = width/3;
        int height3 = height/3;
        int [] middlerangesize = new int[width3*height3];
        ArrayList middleregion = new ArrayList();
        ArrayList middleregionR = new ArrayList();
        ArrayList middleregionG = new ArrayList();
        ArrayList middleregionB = new ArrayList();
        ArrayList<String> pixel2 = new ArrayList();

        //  2. Make 2D array that gets the middle region of the image
        for(int h = height3; h<height3+height3; h++) {
            for (int w = width3; w<width3+width3; w++) {
                int pixel = bitmap.getPixel(w, h);
               // pixel2.add ("(" + bitmap.getPixel(w, h)+")");
                R = Color.red(pixel);
                G = Color.green(pixel);
                B = Color.blue(pixel);
                //3. make count functions that counts the most frequent pixel
               int [] onepixelRGB  = {R,G,B};
                //middleregion.add(width3*h + w, {R,G,B}); // formula for converting 2D array to 1D array
                middleregionR.add(R);
                middleregionG.add(G);
                middleregionB.add(B);
                middleregion.add(onepixelRGB);

            }
        }
        int sizeoflist = middleregionB.size();
        // Make 2D array
        // find most common element
        List<Integer> list2 = Arrays.asList(1,3,4,3,4,3,2,3,3,3,3,3);
     //   System.out.println("Most common" + mostCommon(middleregionR));

        for(int i=0; i<sizeoflist; i++)
        {
            pixel2.add(i,  "(" + middleregionR.get(i) + ", " + middleregionG.get(i) + ", " + middleregionB.get(i) + ")");
        }

        //-------------------------------
        Map<String, Integer> stringsCount = new HashMap<>();
        for(String s: pixel2)
        {
            Integer c = stringsCount.get(s);
            if(c == null) c = new Integer(0);
            c++;
            stringsCount.put(s,c);
        }
        Map.Entry<String,Integer> mostRepeated = null;
        for(Map.Entry<String, Integer> e: stringsCount.entrySet())
        {
            if(mostRepeated == null || mostRepeated.getValue()<e.getValue())
                mostRepeated = e;
        }
         //-------------------------------
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                context);

        // Title of dialog
        alertDialogBuilder.setTitle("RGB value");

// AlertDialog settings
        alertDialogBuilder
                //.setMessage("RGB: (" + mostCommon(middleregionR) + "," + mostCommon(middleregionG) + ", " + mostCommon(middleregionB) + ")")
                .setMessage("RGB: " + mostRepeated + "pixels")
                .setCancelable(true);

        // Create Dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // Show dialog
        alertDialog.show();
    }
}
