package com.example.jss.myclosettest;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {

    // https://stackoverflow.com/questions/24784871/how-to-mysql-jdbc-driver-to-android-studio
    String geturl = "https://www.instagram.com/p/BbVejOOgiZW/?hl=en&taken-by=voguemagazine";
    String geturl2 = "https://www.instagram.com/p/BbAMd0PgnH5/?hl=en&taken-by=calvinklein";

    TextView textView;
    EditText editText; EditText editText_color;

    // Soo's DB settings -> should change to your system's settings
    private static final String DB_URL = "jdbc:mysql://192.168.56.1:3306/mycloset_images";
    private static final String user = "root";
    private static final String password = "qldgkqur88510";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);
        editText = (EditText) findViewById(R.id.editText);
        editText_color = (EditText) findViewById(R.id.editText_color);

    }
    public void btnConn (View view){
        Send objSend = new Send();
        objSend.execute("");
    }

    private class Send extends AsyncTask<String, String, String>
    {
        String  msg = "";
       // String text = geturl;
        String text = editText.getText().toString();
        String color = editText_color.getText().toString();

        @Override
        protected void onPreExecute() {
            textView.setText("Please wait.. inserting data now!");
        }

        @Override
        protected String doInBackground(String... strings)
        {
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, user, password);
                if(conn == null)
                {
                    msg = "wrong connection";
                }

                else
                {
                    // urladdress is the name for the column in the table, imageurl
                    String query = "INSERT INTO imageurl (urladdress) VALUES ('" + text + "')";
                    Statement stnt = conn.createStatement();
                    stnt.executeUpdate(query);

                    // color is the name for the column in the table, imageurl
                    String colorquery = "INSERT INTO imageurl (color) VALUES ('" + color + "')";
                    Statement stnt2 = conn.createStatement();
                    stnt2.executeUpdate(colorquery);
                    msg = "successful connection";

               }
                conn.close();

            }
            catch (Exception e)
            {
                msg = "wrong connection - exception";

                e.printStackTrace();
            }
            return msg;
        }

        @Override
        protected void onPostExecute(String msg){
            textView.setText(msg);
        }
    }


}
